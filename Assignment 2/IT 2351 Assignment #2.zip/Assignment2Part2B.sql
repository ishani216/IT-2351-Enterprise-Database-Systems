-- *****************************************************
-- Ishani Nanavaty, Spring 2021
-- IT 2351 Assignment 2 Part 2B Prof. Tamerlano 
/*This query is meant to concatenate the names then join the information from the two tables and order it.*/
-- *****************************************************
select concat(customers.customer_first_name, " ", customers.customer_last_name) as customer, customers.customer_city, customers.customer_state, orders.order_date, orders.shipped_date
from customers INNER JOIN orders on orders.customer_id = customers.customer_id
order by customers.customer_state, customers.customer_city, customers.customer_last_name, customers.customer_first_name;
