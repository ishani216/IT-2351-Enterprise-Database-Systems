-- *****************************************************
-- Ishani Nanavaty, Spring 2021
-- IT 2351 Assignment 2 Part 2C Prof. Tamerlano 
/*I had to combine two tables so I used the inner join so that these rows were shown in detail*/
-- *****************************************************
SELECT orders.customer_id, orders.order_date, order_details.item_id, order_details.order_qty 
from orders
INNER JOIN order_details on orders.order_id = order_details.order_id;