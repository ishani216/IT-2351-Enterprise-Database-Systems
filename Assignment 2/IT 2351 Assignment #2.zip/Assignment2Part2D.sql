-- *****************************************************
-- Ishani Nanavaty, Spring 2021
-- IT 2351 Assignment 2 Part 2D Prof. Tamerlano 
/*In this query, I replaced item_id with artist, then joined the artist table, 
so that there is now details from the three different tables*/
-- *****************************************************
SELECT customer_id, order_date, order_qty, artist
FROM orders
INNER JOIN order_details
ON orders.order_id = order_details.order_id
JOIN items 
ON items.item_id = order_details.item_id;
