-- *****************************************************
-- Ishani Nanavaty, Spring 2021
-- IT 2351 Assignment 2 Part 2E Prof. Tamerlano 
/*In this query I am replacing customer_id with customer name and modifying the code so that
the results are shown*/
-- *****************************************************
SELECT concat(customer_first_name, customer_last_name) as  customer, order_date, order_qty, artist
FROM customers
INNER JOIN orders
ON customers.customer_id = orders.customer_id
INNER JOIN order_details
ON orders.order_id = order_details.order_id
INNER JOIN items
ON items.item_id = order_details.item_id;



