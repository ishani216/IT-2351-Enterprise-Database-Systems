-- *****************************************************
-- Ishani Nanavaty, Spring 2021
-- IT 2351 Assignment 2 Part 2F Prof. Tamerlano 
/*This query names all of the titles that have an order quantity greater than 1*/
-- *****************************************************
SELECT title, order_qty
FROM order_details, items
WHERE order_qty > 1