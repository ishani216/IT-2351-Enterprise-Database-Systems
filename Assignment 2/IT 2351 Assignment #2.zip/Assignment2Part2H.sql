-- *****************************************************
-- Ishani Nanavaty, Spring 2021
-- IT 2351 Assignment 2 Part 2H Prof. Tamerlano 
/* This query is to insert a row of data to the pre-existing customers table*/
-- *****************************************************
INSERT INTO customers
VALUES (00865, 'Ishani', 'Nanavaty', '351 Miner Rd','Cleveland', 'OH', '44143', '4404428704', '4406660739');
SELECT customer_id, customer_first_name, customer_last_name, customer_address, customer_city
FROM customers
WHERE customer_first_name = 'Ishani'
