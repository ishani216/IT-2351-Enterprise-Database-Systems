-- *****************************************************
-- Ishani Nanavaty, Spring 2021
-- IT 2351 Assignment 2 Part 2I Prof. Tamerlano 
/*This query is to update the unit price by 10% for all items with a unit price > 17*/
-- *****************************************************
UPDATE items 
SET unit_price = unit_price * 1.1
WHERE unit_price > 17 AND item_id <> 0;
