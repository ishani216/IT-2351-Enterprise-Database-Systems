-- *****************************************************
-- Ishani Nanavaty, Spring 2021
-- IT 2351 Assignment 2 Part 2A Prof. Tamerlano 
/*This query it to use the join method to join two tables then sort them from title followed by artist
The primary key is joined with the foreign key after 'ON'.*/
-- *****************************************************
SELECT items.title, items.artist, items.unit_price, order_details.order_qty
FROM order_details
INNER JOIN items on order_details.item_id = items.item_id
order by items.title, items.artist;