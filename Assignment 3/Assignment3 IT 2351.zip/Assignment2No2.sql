-- *****************************************************
-- Ishani Nanavaty, Spring 2021
-- IT 2351 Assignment 2 No2 Prof. Tamerlano
-- Query to select fields from tables
-- *****************************************************
USE IshaniNanavaty_guitar_shop;
SELECT count(ship_amount) as count_orders, sum(ship_amount) as Ship_Value
from orders