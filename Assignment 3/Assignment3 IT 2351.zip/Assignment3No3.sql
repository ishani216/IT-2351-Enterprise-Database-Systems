-- *****************************************************
-- Ishani Nanavaty, Spring 2021
-- IT 2351 Assignment 3 No3 Prof. Tamerlano
/* I am joining two tables to show the category name and to show each row with 
products and the cost of the most expensive product*/
-- *****************************************************
SELECT categories.category_name, COUNT(products.product_id) as count, max(products.list_price) as max_price
FROM categories
INNER JOIN products 
WHERE categories.category_id = products.category_id
group by categories.category_name
ORDER BY COUNT(products.product_id) desc


