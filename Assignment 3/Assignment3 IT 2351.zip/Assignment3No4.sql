-- *****************************************************
-- Ishani Nanavaty, Spring 2021
-- IT 2351 Assignment 3 No4 Prof. Tamerlano
/* In this query, I showed the quantity for the total purchased in each category
with a ROLLUP and the IF GROUPING included*/
-- *****************************************************
SELECT IF(GROUPING(categories.category_id), 'Total Quantity per Category', categories.category_name) AS "Category_Name",
IF(GROUPING(products.product_id), 'Total Quantity per Product', products.product_name) AS "Product_Name",
categories.category_name,
products.product_name,
SUM(order_items.quantity) AS "Total_Quantity"
FROM categories
INNER JOIN products
ON categories.category_id = products.category_id
INNER JOIN order_items
ON products.product_id = order_items.product_id
GROUP BY categories.category_id, products.product_id WITH ROLLUP;