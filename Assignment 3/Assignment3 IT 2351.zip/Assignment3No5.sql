-- *****************************************************
-- Ishani Nanavaty, Spring 2021
-- IT 2351 Assignment 3 No5 Prof. Tamerlano
/* I made sure that the output was the same but I did not use JOIN, I used WHERE and IN*/
-- *****************************************************
SELECT DISTINCT category_name
from categories
WHERE category_id IN (SELECT category_id from products)
order by category_name